<?php 
include('../db/db.php'); 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <title>Order Management</title>
</head>
<body>

    <!-- Back Button to Admin Dashboard -->
    <div class="container mt-4">
        <a href="../db/admin.php" class="btn btn-secondary">Back</a>
    </div>

    <!-- Search Form for Orders -->
    <div class="container mt-4">
        <h2>Search Orders</h2>
        <form method="GET" action="orderList.php">
            <div class="row">
                <div class="col-md-3">
                    <label for="order_date">Order Date</label>
                    <input type="date" name="order_date" id="order_date" class="form-control" value="<?php echo isset($_GET['order_date']) ? $_GET['order_date'] : ''; ?>">
                </div>
                <div class="col-md-3">
                    <label for="order_status">Order Status</label>
                    <select name="order_status" id="order_status" class="form-control">
                        <option value="">Select Status</option>
                        <option value="Processing" <?php echo (isset($_GET['order_status']) && $_GET['order_status'] == 'Processing') ? 'selected' : ''; ?>>Processing</option>
                        <option value="Shipped" <?php echo (isset($_GET['order_status']) && $_GET['order_status'] == 'Shipped') ? 'selected' : ''; ?>>Shipped</option>
                        <option value="Delivered" <?php echo (isset($_GET['order_status']) && $_GET['order_status'] == 'Delivered') ? 'selected' : ''; ?>>Delivered</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="customer_name">Customer Name</label>
                    <input type="text" name="customer_name" id="customer_name" class="form-control" value="<?php echo isset($_GET['customer_name']) ? $_GET['customer_name'] : ''; ?>">
                </div>
                <div class="col-md-3">
                    <label for="payment_status">Payment Status</label>
                    <select name="payment_status" id="payment_status" class="form-control">
                        <option value="">Select Payment Status</option>
                        <option value="Paid" <?php echo (isset($_GET['payment_status']) && $_GET['payment_status'] == 'Paid') ? 'selected' : ''; ?>>Paid</option>
                        <option value="Pending" <?php echo (isset($_GET['payment_status']) && $_GET['payment_status'] == 'Pending') ? 'selected' : ''; ?>>Pending</option>
                    </select>
                </div>
            </div>
            <button type="submit" class="btn btn-primary mt-3">Search</button>
        </form>
    </div>

    <div class="container mt-5">
        <h1>Order Management</h1>
        
        <!-- Table of Orders -->
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Customer Name</th>
                    <th>Email</th>
                    <th>Total Amount</th>
                    <th>Status</th>
                    <th>Payment Status</th>
                    <th>Order Placed</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Get search filters
                $orderDate = isset($_GET['order_date']) ? $_GET['order_date'] : '';
                $orderStatus = isset($_GET['order_status']) ? $_GET['order_status'] : '';
                $customerName = isset($_GET['customer_name']) ? $_GET['customer_name'] : '';
                $paymentStatus = isset($_GET['payment_status']) ? $_GET['payment_status'] : '';

                // Start building the SQL query with "WHERE 1"
                $sql = "SELECT * FROM orders WHERE 1"; // WHERE 1 is always true, making it easier to append conditions
                
                // Apply filters if they are set
                if ($orderDate) {
                    $sql .= " AND order_date = '$orderDate'";  // Filter by order date
                }

                if ($orderStatus) {
                    $sql .= " AND status = '$orderStatus'";  // Filter by order status
                }

                if ($customerName) {
                    $sql .= " AND customer_name LIKE '%$customerName%'";  // Filter by customer name
                }

                if ($paymentStatus) {
                    $sql .= " AND payment_status = '$paymentStatus'";  // Filter by payment status
                }

                // Execute the query
                $result = $conn->query($sql);

                // Check if any orders were found
                if ($result->num_rows > 0) {
                    // Display the orders in the table
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>{$row['id']}</td>
                                <td>{$row['customer_name']}</td>
                                <td>{$row['customer_email']}</td>
                                <td>\${$row['total_amount']}</td>
                                <td>{$row['status']}</td>
                                <td>{$row['payment_status']}</td>
                                <td>{$row['order_date']}</td>
                                <td>
                                    <a href='update-order.php?id={$row['id']}&status=Shipped' class='btn btn-sm btn-warning'>Mark as Shipped</a>
                                    <a href='update-order.php?id={$row['id']}&status=Delivered' class='btn btn-sm btn-success'>Mark as Delivered</a>
                                </td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='8' class='text-center'>No orders found</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
