<?php
include('../backend/db/db.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>K Depot</title>
    <link rel="stylesheet" href="shop.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://kit.fontawesome.com/93a4ced81e.js"></script>
    <link rel="icon" href="../../pics/logo.png" type="image/gif" sizes="16x16">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .container {
            padding: 40px 20px;
        }
        .product-card {
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 15px;
            text-align: center;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s, box-shadow 0.2s;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            height: 100%;
        }
        .product-card:hover {
            transform: scale(1.05);
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
        }
        .product-image {
            max-height: 150px;
            object-fit: contain;
            margin-bottom: 10px;
        }
        .product-title {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .product-price {
            color: #28a745;
            font-size: 16px;
            margin-bottom: 10px;
        }
        .btn-buy {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
        }
        .btn-buy:hover {
            background-color: #0056b3;
        }
        .product-description {
            font-size: 14px;
            margin-bottom: 15px;
            overflow: hidden; 
            text-overflow: ellipsis; 
            display: -webkit-box;
            -webkit-line-clamp: 3; 
            -webkit-box-orient: vertical;
        }
    </style>
</head>
<body>
    
    <section id="header">
        <a href="#"><img src="../../pics/logo.png" class="logo"></a>
        <div>
            <ul id="navbar">
                <li><a href="index.html">HOME</a></li>
                <li><a href="shop.php" class="active">SHOP</a></li>
                <li><a href="about.html">ABOUT US</a></li>
                <li><a href="contact.html">CONTACT</a></li>
                <li><a href="cart.html"><i class="fa-solid fa-cart-shopping"></i></a></li>
            </ul>
        </div>
    </section>


    <section id="bg">

        <div>
            <img src="../../pics/bg.png">
            <h1>Shop Now</h1>
        </div>

    </section>


    <section class="product" id="product">
        <h2>KITCHEN EQUIPMENTS</h2>
    
        <div class="container">
            <div class="row row-cols-1 row-cols-md-3 g-4">  
                <?php
                // Fetch products from the database
                $sql = "SELECT * FROM products";
                $result = $conn->query($sql);
    
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "
                        <div class='col'>
                            <div class='product-card'>
                                <img src='../backend/uploads/{$row['image_url']}' alt='Product Image' class='product-image img-fluid'>
                                <div class='product-title'>{$row['product_name']}</div>
                                <div class='product-price'>₱ " . number_format($row['price'], 2) . "</div>
                                <p class='product-description'>{$row['description']}</p>
                                <button class='btn btn-buy'>Buy Now</button>
                            </div>
                        </div>";
                    }
                } else {
                    echo "<p class='text-center'>No products found.</p>";
                }
    
                $conn->close();
                ?>
            </div>
        </div>
    </section>
    
</body>
</html>